public class Ex2 {
    public static void main(String[] args) {
        Monitor monitor = new Monitor();

        Thread t1 = new Thread(() -> {
            while (true) {
                monitor.openReading();
                System.out.println("Thread 1 accessing the monitor for reading");
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                monitor.closeReading();
                System.out.println("Thread 1 closing the monitor for reading");

                monitor.openWriting();
                System.out.println("Thread 1 accessing the monitor for writing");
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                monitor.closeWriting();
                System.out.println("Thread 1 closing the monitor for writing");
            }
        });

        Thread t2 = new Thread(() -> {
            while (true) {
                monitor.openReading();
                System.out.println("Thread 2 accessing the monitor for reading");
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                monitor.closeReading();
                System.out.println("Thread 2 closing the monitor for reading");

                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                monitor.openWriting();
                System.out.println("Thread 2 accessing the monitor for writing");
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                monitor.closeWriting();
                System.out.println("Thread 2 closing the monitor for writing");
            }
        });

        t1.start();
        t2.start();
    }
}

