
    import java.sql.*;
public class Ex4 {
    private Connection connection;

    public Ex4(String url, String username, String password) throws SQLException {
        connection = DriverManager.getConnection(url, username, password);
    }

    public void connectAndFetchData() {
        try {
            String query = "SELECT * FROM nom_taula";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            // Espera 3 segons (3000 mil·lisegons)
            Thread.sleep(3000);

            // Mostra els resultats
            while (resultSet.next()) {
                // Aquí pots accedir als camps dels registres i fer el que vulguis amb ells
                String field1 = resultSet.getString("camp1");
                int field2 = resultSet.getInt("camp2");
                System.out.println("Camp1: " + field1 + ", Camp2: " + field2);
            }

            // Tanca el ResultSet i l'Statement (la connexió es tancarà més endavant)
            resultSet.close();
            statement.close();
        } catch (SQLException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/nom_bd";
        String username = "usuari";
        String password = "contrasenya";

        try {
            Ex4 database = new Ex4(url, username, password);

            // Crea una instància de Thread per cada fil i passa la mateixa instància de BD
            Thread thread1 = new Thread(() -> {
                for (int i = 0; i < 10; i++) {
                    database.connectAndFetchData();
                }
            });

            Thread thread2 = new Thread(() -> {
                for (int i = 0; i < 10; i++) {
                    database.connectAndFetchData();
                }
            });

            // Inicia els fils
            thread1.start();
            thread2.start();

            // Espera que els fils finalitzin
            try {
                thread1.join();
                thread2.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Tanca la connexió
            database.connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

