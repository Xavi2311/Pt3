import java.sql.*;
import java.util.concurrent.Semaphore;

public class Ex6 {
    private static final String URL = "jdbc:mysql://localhost:3306/bar";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "Admin123";
    private static final int ITERATIONS = 10;

    private Semaphore semaphore = new Semaphore(1);

    public void connectAndQuery() {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            
            semaphore.acquire();
            System.out.println("Semaforo hace algo");

            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM producte");
            Thread.sleep(3000);

            while (resultSet.next()) {

                int id = resultSet.getInt(1);
                String nombre = resultSet.getString(2);
                String edad = resultSet.getString(3);

                System.out.println("ID: " + id + ", Nombre: " + nombre + "Precio: " + edad);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            // Cerrar el ResultSet, el Statement y la conexión
             if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            
            // Liberar el permiso del semáforo*/
            semaphore.release();

        }
    }

    public static void main(String[] args) {
        Ex6 database = new Ex6();

        Thread thread1 = new Thread(() -> {
            int j=0;
            for (int i = 0; i < ITERATIONS; i++,j++) {
                System.out.println("Fil 1 agafa el permit. Permits restants:"+ database.semaphore.availablePermits());
                System.out.println("Fil 1 "+j);
                database.connectAndQuery();
                System.out.println("Fil 1 deixa el permit. Permits restants:"+ database.semaphore.availablePermits());
            }
        });

        Thread thread2 = new Thread(() -> {
            int j=0;
            for (int i = 0; i < ITERATIONS; i++,j++) {
                System.out.println("Fil 2 agafa el permit. Permits restants:"+ database.semaphore.availablePermits());
                System.out.println("Fil 2 "+j);;
                database.connectAndQuery();
                System.out.println("Fil 2 deixa el permit. Permits restants:"+ database.semaphore.availablePermits());
            }
        });

        thread1.start();
        thread2.start();
    }
}
